//
//  BenfsViewController.swift
//  Mahrshi
//
//  Created by adithya on 10/4/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class BenfsViewController: UIViewController {

    @IBOutlet var t1: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        t1.text = "It is proven that the layout,design,structure of the place you work and stay has a definite bearing on your mental and physical state.The positive or negative vibes flowing in thesestructures affect your peace of mind,your smooth functioning,eventually having a bearing of your health,general well being and also on your prosperity.\n\nEach one of us has aspirations and would appreciate to climb the success ladder to reach new heights.Vastu shastra plays an important role in paving the path of success, prosperity better business prospects and a better lifestyle.\n\nThe positive energies and vibes which would flow into your home and work place would recharge your mind and body and you would be able to work efficiently and effectively which would translate into hapiness,success and good health.\n\nVastusastra is gaining tremendous popularity due to its effectiveness and we have witnessed positive growth and satisfaction with each of our clients. By incorporating vastu sastra principles today,you would be sowing the seeds for a bettertomorrow.\n\n\nIndustrialists & Businessmen\n\n• Experience success,properity and growth.\n\n• Improve sales revenue and profitability.\n\n• Attain strong revenue growth and stability of finances.\n\n• Foster better co-ordination with employees and management etc.\n\n• Minimize and machinery break-down.\n\n• Archive higher output (production).\n\n• Upscale your business and profession.\n\n• Stimulate faster movement of stocks and merchdise.\n\n• Helps to gather more clientele and repute\n\n\n\nprofessions\n\nDoctors,Lawyers,C.A,Architects,Consultants etc.\n\n\n• Helps to gather more clientele and repute.\n\n• Helps to dispense quality advice,suggestions and reports.\n\n• Deliver world class advice and information.\n\n• Create client satisfaction.\n\n• Fosters faster recovery of dues.\n\n• Archive financial stability.\n\n• Experience success,properity and growth.\n\n\n\nHouse - holds\n\n\n• Experience more peace of mind.\n\n• Improves co-ordination with family members.\n\n• Opens up doors for success & properity.\n\n• Helps to improve health and well being.\n\n• Vitalize the fund flow and stabilize the finances.\n\n• Helps in improving concentration on studies.\n\nHelps in timely marriage of children.\n\n• Improves relationship of the wedded couple.\n\n\n\nGovt. Service and Private Jobs\n\n\n• Experience job satisfaction.\n\n• Vitalize the resume and job profile.\n\n• Fosters better team spirit and better co-ordination.\n\n• Maintain peace of mind.\n\n• Archive stability of finances.\n\n• Opens up doors for success & prosperity.\n\n\n\nStudents\n\n\n• Helps in improving concentration on studies.\n\n• Archive improved results and better academic mark-sheet.\n\n• Empowers the student to be more focused onthe higher goals for the future."
    }
    

   

}
