//
//  WebViewController.swift
//  Mahrshi
//
//  Created by adithya on 10/5/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class WebViewController: UIViewController {
    var vv = ""
    @IBOutlet var webview: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let url = URL(string: vv)
                webview.loadRequest(URLRequest(url: url!))
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
