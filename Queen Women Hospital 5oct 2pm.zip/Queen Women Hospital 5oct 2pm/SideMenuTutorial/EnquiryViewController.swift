//
//  EnquiryViewController.swift
//  Ankur app
//
//  Created by adithya on 9/13/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import MessageUI

class EnquiryViewController: UIViewController,MFMailComposeViewControllerDelegate,UITextFieldDelegate,UITextViewDelegate,UITableViewDataSource,UITableViewDelegate {
    
    let serviceList = ["Obstetrics","Gynecology","Sonography","Infertility","Operation","Pre-Conceptonal Counselling","Garbh Sanskar"]

    @IBOutlet var btnservice: UIButton!

    @IBOutlet var servicelbl: UILabel!
    @IBOutlet weak var menuButton: UIBarButtonItem!
    @IBOutlet var FullName: ACFloatingTextfield!
    @IBOutlet weak var ContactNo: ACFloatingTextfield!
    @IBOutlet weak var email: ACFloatingTextfield!
    @IBOutlet weak var address: UITextView!

    
    
    
    
    @IBOutlet var hideview: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
        hideview.isHidden = true
        customizeNavBar()
        sideMenus()
        address.text = "Enter your address"
        address.textColor = UIColor.lightGray
        address.layer.borderColor = UIColor.black.cgColor
        address.layer.borderWidth = 2
    }
    @IBAction func closePopUp(_ sender: AnyObject) {
        hideview.isHidden = true
        
    }
//    @IBAction func textFieldChanged(_ sender: AnyObject) {
//        hideview.isHidden = true
//    }
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
//    {
//        guard let touch:UITouch = touches.first else
//        {
//            return;
//        }
//        if touch.view != tableView
//        {
//           // btnservice.endEditing(true)
//            hideview.isHidden = true
//        }
//    }
//    func textFieldActive() {
//        hideview.isHidden = !hideview.isHidden
//    }
    
    // MARK: UITextFieldDelegate
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        // TODO: Your app can do something when textField finishes editing
//        print("The textField ended editing. Do something based on app requirements.")
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        //txt.resignFirstResponder()

        return true
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"{
            address.resignFirstResponder()
            return false
        }
        return true
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == "" {
            textView.text = "Enter your address"
            textView.textColor = UIColor.lightGray
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Enter your address" {
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return serviceList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.nameLabel.text = serviceList[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
       // txt.text = serviceList[indexPath.row]
        btnservice.setTitle(serviceList[indexPath.row], for: UIControlState.normal)
        servicelbl.text = serviceList[indexPath.row]
        hideview.isHidden = true
        //  tableView.isHidden = true
    }
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["rajucshah@gmail.com"])
        //rajucshah@gmail.com
        mailComposerVC.setSubject("Enquiry form")
        mailComposerVC.setMessageBody("Name:"+self.FullName.text!+"\n"+"Email:"+self.email.text!+"\n"+"Mobile:"+self.ContactNo.text!+"\n"+"Select Our Services:"+self.servicelbl.text!+"\n"+"Address"+self.address.text!, isHTML: false)
        
        return mailComposerVC
    }
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    @IBAction func services(_ sender: Any) {
        hideview.isHidden = false
    }
    
    @IBAction func makeAppointment(_ sender: Any) {
        if self.FullName.text! == ""{
            FullName.showErrorWithText(errorText: "Enter valid Text")
            FullName.errorTextColor = UIColor.red
            FullName.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            FullName.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            FullName.showErrorWithText(errorText: "Ok")
            FullName.errorTextColor = UIColor.green
            FullName.placeHolderColor = UIColor.black
            FullName.errorLineColor = UIColor.green
            FullName.selectedLineColor =  UIColor.black
            FullName.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.email.text! == ""{
            email.showErrorWithText(errorText: "Enter valid Text")
            email.errorTextColor = UIColor.red
            email.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            email.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            email.showErrorWithText(errorText: "Ok")
            email.errorTextColor = UIColor.green
            email.placeHolderColor = UIColor.black
            email.errorLineColor = UIColor.green
            email.selectedLineColor =  UIColor.black
            email.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.ContactNo.text! == ""{
            ContactNo.showErrorWithText(errorText: "Enter valid Text")
            ContactNo.errorTextColor = UIColor.red
            ContactNo.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            ContactNo.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            ContactNo.showErrorWithText(errorText: "Ok")
            ContactNo.errorTextColor = UIColor.green
            ContactNo.placeHolderColor = UIColor.black
            ContactNo.errorLineColor = UIColor.green
            ContactNo.selectedLineColor =  UIColor.black
            ContactNo.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.address.text! == ""{
            address.layer.borderColor = UIColor.red.cgColor
            
        }
        else
        {
            //  address.layer.borderColor = UIColor.green.cgColor
            
        }
        
        
        
        if self.FullName.text! == "" || self.email.text! == "" || self.ContactNo.text! == "" || self.address.text! == "" {
            
            
            
            let alert = UIAlertController(title: "Application Form", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        else{
            
            
            
            
            let mailComposeViewController = configureMailController()
            
            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController, animated: true, completion: nil)
            } else {
                showMailError()
            }
            
        }
        //
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
