//
//  CollectionViewCell.swift
//  testibg
//
//  Created by adithya on 9/14/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imgg: UIImageView!
    
}
