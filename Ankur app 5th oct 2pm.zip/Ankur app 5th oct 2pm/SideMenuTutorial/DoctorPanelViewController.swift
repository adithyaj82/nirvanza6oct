//
//  VastuViewController.swift
//  Mahrshi app
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Parth Changela. All rights reserved.
//

import UIKit

class DoctorPanelViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorEdu = ["Dr.Raju C. Shah (M.D.,D.Ped,F.I.A.P, FRCPCH(UK))","Dr.Pratima R. Shah (M.D.,D.Ped)","Dr.Harish Chaudhari(M.D.Peds)","Dr.Vivek Shukla","Dr.Khanjan Shah"]
    let doctorsList = ["Dr.Raju C. Shah","Dr.Pratima R. Shah","Dr.Harish Chaudhari","Dr.Vivek Shukla","Dr.Khanjan Shah"]
    let doctorImages = ["Raju","Pratima","Harish","Mehul.jpg","Khanjan"]
    
    let doctordata = ["Dr. Raju Shah is one of most reputed and senior most Pediatrician of Ahmedabad. He is the first to establish a private sector NICU and PICU with ventilators in North and central Gujarat. He is pioneer in the field of Neonatology, Pediatric Intensive Care and Infectious diseases in Gujarat.\n\nHe has an experience of more than 40 years in the field of Paediatrics and Neonatology. He is Medical Director at Ankur Institute of Child Health.\n\nHe was Former Professor and Head of Department at GCS Medical College, Ahmedabad.\n\nHe was National president of IAP during the year 2005 and President of Pediatric Association of SAARC from 2005 to 2008.","Dr. Pratima Shah is a beloved teacher and eminent pediatrician of Ahmedabad. She has an experience of more than 40 years in the field of Pediatrics and Neonatology.\n\nShe is Director of Ankur Institute of Child Health. She was Professor at Medical College, Vaghodia. She also was former Incharge of NICU at Civil hospital, Ahmedabad.\n\nShe has trained hundreds of pediatricians which are flourishing in their field.","Dr. Harish Chaudhari is associated with Ankur Institute of Child Health since more than 25 years.\n\nHe has taken training in Pediatric and Neonatal intensive care and is taking care of all critical babies in Ankur Institute of Child Health.\n\nHe has excellent management skills and is the Medical Superintendent of Ankur Institute of Child Health.","Modern Medicine has become extremely specialized. He was trained in Neonatology at Level III NICU (NNF) at Deenanath mangeshkar hospital and Research Center, Pune. It is well recognized training center for Neonatology, Fetal Medicine, Neonatal Surgery and Advanced Obstretics & Gynecology. In highly specialized area of Neonatology, He has skills in diagnosis and treatment of newborn infants with Prematurity, Breathing disorders, Infections and Critically ill Newborns including Surgical patients.\n\nHe is an expert in Neonatal Resuscitation and attended more than 5000 delivery Calls. He is certified Instructor for IAP-NNF Neonatal Resuscitation Program. He has received specialized training in Functional Echocardiography, Neonatal Nutrition, Advanced Neonatal Ventilation, Neonatal Sepsis, Amplitude EEG and Therapeutic Hypothermia. He has special Interest in treatment of Preemies-Premature Babies and Developmental Care.","Dr. Khanjan C. Shah is a Pediatric Intensivist associated with Ankur Institute of Child Health since last 2 years. After finishing his MD Pediatrics from V.S. Hospital Ahmedabad, he did his fellowship in Pediatric Critical Care from Prestigious P.D.Hinduja Hospital and Research Centre Mumbai.\n\nLater he joined as Junior consultant in Tertiary Pediatric ICU at Rainbow Hospital) and then joined Ankur Institute Of Child Health as Consultant Pediatric Intensivist. He is trained in conventional mechanical ventilation, high frequency oscillatory ventilation (HFOV), Video Laryngoscopy, ICP bolt monitoring, Invasive arterial BP monitoring and Central venous catheter placement, peritoneal dialysis. Intercostal Drainage tube insertion. He is managing all the complicated Pediatric illness."]
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! DoctorPanelTableViewCell
        cell.doctorList.text = doctorsList[indexPath.row]
       // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])

        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false

        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vmi = self.storyboard?.instantiateViewController(withIdentifier: "Doctor")as! DoctorPanelDetailViewController
        vmi.str =  doctorEdu[indexPath.row]
        vmi.str2 =  doctorImages[indexPath.row]
        vmi.str3 =  doctordata[indexPath.row]
        self.navigationController?.pushViewController(vmi, animated: true)

    }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
