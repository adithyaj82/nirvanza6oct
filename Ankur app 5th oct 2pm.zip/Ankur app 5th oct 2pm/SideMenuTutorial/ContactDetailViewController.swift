//
//  VideoDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ContactDetailViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://www.google.com/maps/place/Ankur+Institute+of+Child+Health+Care/@23.040867,72.562904,14z/data=!4m5!3m4!1s0x0:0x7ab5916bd746cdf8!8m2!3d23.0321179!4d72.56863?hl=en-US")
        myWebView.loadRequest(URLRequest(url: url!))
        customizeNavBar()
        // Do any additional setup after loading the view.
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    
}
