//
//  DoctorPanelDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class DoctorPanelDetailViewController: UIViewController {
    var str = String()
    var str2 = String()
    var str3 = String()

    @IBOutlet var labb: UILabel!
    @IBOutlet var imgg: UIImageView!
    @IBOutlet var txtvw: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       labb.text =  str
        imgg.image = UIImage(named: str2)
        txtvw.text = str3
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
